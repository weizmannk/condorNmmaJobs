

python compare_injection.py --original-injection-file runs/O6/bns_astro/injections.xml --final-injection-file runs/O6/bns_astro/events.xml.gz --outdir ./bns

python compare_injection.py --original-injection-file runs/O6/nsbh_astro/injections.xml --final-injection-file runs/O6/nsbh_astro/events.xml.gz --outdir ./nsbh

python compare_injection.py --original-injection-file runs/O6/bbh_astro/injections.xml --final-injection-file runs/O6/bbh_astro/events.xml.gz --outdir ./bbh

