import os
import argparse
import json
import sys
import pandas as pd

import numpy as np
import scipy.interpolate

import lalsimulation as lalsim
from gwpy.table import Table
try:
    import ligo.lw  # noqa F401
except ImportError:
    raise ImportError("You do not have ligo.lw install: $ pip install python-liw-lw")

import matplotlib
import matplotlib.pyplot as plt
import matplotlib.gridspec as gridspec

def xml_to_dataframe(prior_file):
    table = Table.read(prior_file, format="ligolw", tablename="sim_inspiral")
    injection_values = {
        "mass_1": [],
        "mass_2": [],
        "luminosity_distance": [],
        "psi": [],
        "phase": [],
        "geocent_time": [],
        "ra": [],
        "dec": [],
        "spin_1": [],
        "spin_2": [],
    }
    for row in table:
        injection_values["mass_1"].append(max(float(row["mass1"]), float(row["mass2"])))
        injection_values["mass_2"].append(min(float(row["mass1"]), float(row["mass2"])))
        injection_values["luminosity_distance"].append(float(row["distance"]))
        injection_values["psi"].append(float(row["polarization"]))
        injection_values["phase"].append(float(row["coa_phase"]))
        injection_values["geocent_time"].append(float(row["geocent_end_time"]))
        injection_values["ra"].append(float(row["longitude"]))
        injection_values["dec"].append(float(row["latitude"]))
        injection_values["spin_1"].append(float(row["spin1z"]))
        injection_values["spin_2"].append(float(row["spin2z"]))

    injection_values = pd.DataFrame.from_dict(injection_values)
    return injection_values


def main():

    parser = argparse.ArgumentParser(
        description="Process a bilby injection file for nmma consumption"
    )
    parser.add_argument(
        "--original-injection-file",
        type=str,
        help="The xml injection file or bilby injection json file to be used (optional)"
    )
    parser.add_argument(
        "--final-injection-file",
        type=str,
        help="The xml injection file or bilby injection json file to be used (optional)"
    )
    parser.add_argument(
        "--outdir",
        type=str
    )

    args = parser.parse_args()

    original_dataframe = xml_to_dataframe(args.original_injection_file)
    final_dataframe = xml_to_dataframe(args.final_injection_file)

    if not os.path.isdir(args.outdir):
        os.makedirs(args.outdir)

    for col in original_dataframe.columns:

        vals = original_dataframe[col]
        bin_edges_1 = np.linspace(np.min(vals), np.max(vals), 31)
        dhist_1, bin_edges = np.histogram(vals, bins=bin_edges_1)
        bins_1 = (bin_edges[1:]+bin_edges[:-1])/2.0

        vals = final_dataframe[col]
        dhist_2, bin_edges = np.histogram(vals, bins=bin_edges_1)
        bins_2 = (bin_edges[1:]+bin_edges[:-1])/2.0

        fig = plt.figure(figsize=(12,12))
        gs = gridspec.GridSpec(3, 1, hspace=0.5)
        ax1 = fig.add_subplot(gs[:2, 0])
        ax2 = fig.add_subplot(gs[2, 0], sharex=ax1)
        plt.axes(ax1)
        plt.plot(bins_1, dhist_1, 'k-', drawstyle='steps', label='original')
        plt.plot(bins_2, dhist_2, 'b--', drawstyle='steps', label='final')
        ax1.set_yscale('log')
        plt.legend()
        plt.ylabel('Probability Density Function')
        plt.axes(ax2)
        plt.plot(bins_1, dhist_1/dhist_2, 'k-', drawstyle='steps')
        plt.ylabel('Efficiency')
        plt.xlabel(f'{col}')
        plt.savefig(os.path.join(args.outdir, f'{col}.png'))
        plt.close()

if __name__ == "__main__":
    main()
